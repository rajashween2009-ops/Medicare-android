from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
html = (root / 'app/src/main/assets/index.html').read_text()
scheduler = (root / 'app/src/main/java/com/medicare/companion/ReminderScheduler.java').read_text()
receiver = (root / 'app/src/main/java/com/medicare/companion/MedicineAlarmReceiver.java').read_text()
boot = (root / 'app/src/main/java/com/medicare/companion/BootReceiver.java').read_text()

ET.fromstring(manifest)
ET.parse(root / 'app/src/main/res/values/styles.xml')
assert 'android.permission.INTERNET' not in manifest, 'Offline build must not request INTERNET'
assert 'android.permission.POST_NOTIFICATIONS' in manifest
assert 'android.permission.RECEIVE_BOOT_COMPLETED' in manifest
assert 'android.permission.SCHEDULE_EXACT_ALARM' in manifest
assert '.BootReceiver' in manifest
assert 'const DEFAULT_MEDICATIONS = [];' in html, 'Do not preload fake medicine schedules'
assert 'const DEFAULT_CONTACTS = [];' in html, 'Do not preload fake emergency contacts'
assert 'DEFAULT_MEDICATIONS[0]' not in html, 'Empty medicine list must not crash the test alarm'
assert not re.search(r'<(?:script|link)[^>]+(?:src|href)=["\']https?://', html, re.I), 'External HTML dependency found'
assert 'syncReminders(JSON.stringify(medications))' in html
assert 'scheduleTestReminder' in html and 'scheduleTestReminder' in scheduler
assert 'TEST_NOTIFICATION' in receiver
assert 'setExactAndAllowWhileIdle' in scheduler
assert 'setAndAllowWhileIdle' in scheduler
assert 'ACTION_BOOT_COMPLETED' in boot
assert 'ACTION_TIMEZONE_CHANGED' in boot
print('MediCare static project checks: PASS')
