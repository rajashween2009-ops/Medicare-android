# MediCare Android — offline-first reminder project

This project packages the MediCare web interface inside an Android WebView and schedules medicine reminders with Android `AlarmManager`. Core app screens, CSS, medicine data, and alarm schedules are local; no internet permission is declared.

## Notification behavior

- One daily local alarm is scheduled for each saved medicine time.
- Android posts a high-priority notification with a 10-minute snooze action.
- Exact alarms are used when Android grants exact-alarm access; otherwise an inexact idle-compatible alarm is used and may be delayed.
- Alarms are rebuilt after reboot, app replacement, time/time-zone changes, and exact-alarm access changes.
- The WebView synchronizes its saved medicine list to native Android whenever medicines are saved and when the app starts.
- Fresh installs start with an empty medicine list and blank medical details. No example prescription, fake contact, or sample health condition is preloaded.

## Android permissions and limitations

- Android 13+: allow MediCare notifications.
- Android 12+: allow **Alarms & reminders** for precise timing. If this access is unavailable, Android may delay reminders.
- Do not force-stop the app. A force-stopped Android app may not receive alarms until it is manually opened again.
- Some manufacturers' battery controls can delay background work; test on the actual device.
- A notification cannot appear if notification permission is denied or the app's notification channel is disabled.
- This is a reminder aid, not medical advice or a medical device. A responsible adult/caregiver and prescribing clinician/pharmacist must verify every medicine name, dose, and time.

## Test the Android notification

1. Install the debug APK on an Android phone.
2. Allow MediCare notifications and enable **Alarms & reminders** in Android settings.
3. Add a test medicine using a safe, non-medical test name and a time a few minutes ahead.
4. Tap **Test Medicine Alarm**; the app schedules a separate Android test notification for about one minute later.
5. Confirm the notification appears, then test a normal scheduled reminder with the app backgrounded and after a reboot.

The test button needs at least one medicine saved. Exact timing may vary if Android exact-alarm access or notification permission is disabled.

## Build

Requirements: JDK 17, Gradle 8.7, Android SDK platform/build-tools 35.

```bash
gradle assembleDebug
gradle bundleRelease
```

The GitHub Actions workflow builds a debug APK and an unsigned release AAB. The AAB must be signed with your own release key before Play Store upload. This repository does not contain a signing key.

## QA status

Static checks can validate source syntax, manifest structure, and archive integrity. They do not prove that alarms arrive on a particular phone. Test the installed APK with a near-future medicine time, with the app backgrounded, after reboot, and after changing the time zone. Keep a separate trusted reminder system active until these device tests pass.
