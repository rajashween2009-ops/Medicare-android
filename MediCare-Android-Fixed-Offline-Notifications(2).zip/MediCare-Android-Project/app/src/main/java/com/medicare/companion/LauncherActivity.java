package com.medicare.companion;

import android.annotation.SuppressLint;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Context;
import android.webkit.JavascriptInterface;
import androidx.core.content.ContextCompat;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class LauncherActivity extends AppCompatActivity {
    private WebView webView;
    private boolean pendingExactAlarmPrompt = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        // The app is self-contained: prevent WebView from attempting network loads.
        settings.setBlockNetworkLoads(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new ReminderBridge(this), "AndroidReminders");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("tel".equalsIgnoreCase(scheme)) {
                    startActivity(new Intent(Intent.ACTION_DIAL, uri));
                    return true;
                }
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                    // No web navigation in the offline-first app.
                    return true;
                }
                return false;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) webView.goBack();
                else finish();
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasNotificationPermission() {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission()) {
            pendingExactAlarmPrompt = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 4101 && pendingExactAlarmPrompt) {
            pendingExactAlarmPrompt = false;
            requestExactAlarmAccess();
        }
    }

    public void requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                new AlertDialog.Builder(this)
                    .setTitle("Allow precise medicine reminders")
                    .setMessage("For reminders to appear close to the scheduled time, allow MediCare to set alarms in the next screen. You can continue without it, but reminders may be delayed.")
                    .setNegativeButton("Not now", (d, w) -> {})
                    .setPositiveButton("Open settings", (d, w) -> {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    }).show();
            }
        }
    }

    private static class ReminderBridge {
        private final LauncherActivity activity;
        ReminderBridge(LauncherActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public void syncReminders(String medicinesJson) {
            activity.runOnUiThread(() -> ReminderScheduler.replaceAll(activity, medicinesJson));
        }

        @JavascriptInterface
        public void scheduleTestReminder(String medicineJson) {
            try {
                org.json.JSONObject med = new org.json.JSONObject(medicineJson);
                ReminderScheduler.scheduleTestReminder(activity, med.optString("name", "Test medicine"),
                        med.optString("dosage", ""), med.optString("food", ""));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void requestReminderPermissions() {
            activity.runOnUiThread(() -> {
                if (!activity.hasNotificationPermission()) activity.requestNotificationPermissionIfNeeded();
                else activity.requestExactAlarmAccess();
            });
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        // Re-evaluate exact-alarm access after returning from Android Settings and
        // correct alarms after the device clock or time zone changes.
        ReminderScheduler.rescheduleAll(this);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
