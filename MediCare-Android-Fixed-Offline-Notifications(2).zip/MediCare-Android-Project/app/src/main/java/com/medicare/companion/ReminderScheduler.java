package com.medicare.companion;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

/** Schedules one local daily alarm per saved medicine. No network is used. */
public final class ReminderScheduler {
    static final String PREFS = "medicare_reminders";
    static final String KEY_JSON = "medicines_json";
    private static final String ACTION_MEDICINE_ALARM = "com.medicare.companion.MEDICINE_ALARM";

    private ReminderScheduler() {}

    public static synchronized void replaceAll(Context context, String json) {
        if (json == null) json = "[]";
        final JSONArray medicines;
        try {
            medicines = new JSONArray(json);
        } catch (Exception invalidJson) {
            // Do not overwrite a known-good schedule with malformed WebView data.
            return;
        }

        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String previousJson = prefs.getString(KEY_JSON, "[]");
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;

        try {
            JSONArray previous = new JSONArray(previousJson);
            for (int i = 0; i < previous.length(); i++) {
                JSONObject med = previous.optJSONObject(i);
                if (med != null) cancel(context, manager, med.optString("id", ""));
            }
            // Cancel incoming IDs too, so changed times replace rather than duplicate alarms.
            for (int i = 0; i < medicines.length(); i++) {
                JSONObject med = medicines.optJSONObject(i);
                if (med != null) cancel(context, manager, med.optString("id", ""));
            }
            prefs.edit().putString(KEY_JSON, medicines.toString()).commit();
            for (int i = 0; i < medicines.length(); i++) {
                JSONObject med = medicines.optJSONObject(i);
                if (med != null) scheduleNext(context, manager, med);
            }
        } catch (Exception ignored) {
            // Keep the app usable if one malformed record is encountered.
        }
    }

    static void scheduleNext(Context context, AlarmManager manager, JSONObject med) {
        String id = med.optString("id", "").trim();
        String time = med.optString("time", "");
        if (id.isEmpty() || !time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d")) return;

        String[] parts = time.split(":");
        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
        when.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        if (when.getTimeInMillis() <= System.currentTimeMillis()) when.add(Calendar.DAY_OF_YEAR, 1);

        Intent intent = new Intent(context, MedicineAlarmReceiver.class).setAction(ACTION_MEDICINE_ALARM);
        intent.putExtra("med_id", id);
        intent.putExtra("med_name", med.optString("name", "Medicine"));
        intent.putExtra("dosage", med.optString("dosage", ""));
        intent.putExtra("food", med.optString("food", ""));
        PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        try {
            if (Build.VERSION.SDK_INT >= 31 && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            } else {
                manager.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            }
        } catch (SecurityException denied) {
            // Graceful inexact fallback if exact-alarm access is unavailable/revoked.
            try {
                if (Build.VERSION.SDK_INT >= 23) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
                else manager.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            } catch (SecurityException ignored) { }
        }
    }

    static void cancel(Context context, AlarmManager manager, String id) {
        if (id == null || id.isEmpty()) return;
        Intent intent = new Intent(context, MedicineAlarmReceiver.class).setAction(ACTION_MEDICINE_ALARM);
        PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { manager.cancel(pi); pi.cancel(); }
    }

    public static void scheduleTestReminder(Context context, String name, String dosage, String food) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        Intent intent = new Intent(context, MedicineAlarmReceiver.class)
                .setAction("com.medicare.companion.TEST_NOTIFICATION");
        intent.putExtra("med_id", "medicare-test-notification");
        intent.putExtra("med_name", name == null || name.trim().isEmpty() ? "Test medicine" : name);
        intent.putExtra("dosage", dosage == null ? "" : dosage);
        intent.putExtra("food", food == null ? "" : food);
        PendingIntent pi = PendingIntent.getBroadcast(context, 740021, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long triggerAt = System.currentTimeMillis() + 60_000L;
        try {
            if (Build.VERSION.SDK_INT >= 31 && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                manager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException denied) {
            try { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi); }
            catch (SecurityException ignored) { }
        }
    }

    public static void rescheduleAll(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, "[]");
        replaceAll(context, json);
    }
}
