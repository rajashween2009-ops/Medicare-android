package com.medicare.companion;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;

public class MedicineAlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "medicine_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        if ("com.medicare.companion.SNOOZE".equals(intent.getAction())) {
            scheduleSnooze(context, intent);
            return;
        }
        if ("com.medicare.companion.TEST_NOTIFICATION".equals(intent.getAction())) {
            showNotification(context, intent.getStringExtra("med_id"), intent.getStringExtra("med_name"),
                    intent.getStringExtra("dosage"), intent.getStringExtra("food"));
            return;
        }
        String medId = intent.getStringExtra("med_id");
        String name = intent.getStringExtra("med_name");
        String dosage = intent.getStringExtra("dosage");
        String food = intent.getStringExtra("food");
        showNotification(context, medId, name, dosage, food);
        rescheduleThisMedicine(context, medId);
    }

    private void showNotification(Context context, String id, String name, String dosage, String food) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Medicine reminders", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(context, LauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(context, 7000 + (id == null ? 0 : id.hashCode()), open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent snooze = new Intent(context, MedicineAlarmReceiver.class).setAction("com.medicare.companion.SNOOZE");
        snooze.putExtra("med_id", id); snooze.putExtra("med_name", name); snooze.putExtra("dosage", dosage); snooze.putExtra("food", food);
        PendingIntent snoozePi = PendingIntent.getBroadcast(context, 8000 + (id == null ? 0 : id.hashCode()), snooze, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String detail = (dosage == null ? "" : dosage) + ((food == null || food.isEmpty()) ? "" : " • " + food);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("MediCare medicine reminder")
            .setContentText("It is time for " + (name == null ? "your medicine" : name) + (detail.isEmpty() ? "" : " — " + detail))
            .setStyle(new NotificationCompat.BigTextStyle().bigText("Please check your prescribed schedule. " + (name == null ? "Medicine" : name) + (detail.isEmpty() ? "" : " — " + detail)))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(openPi)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Snooze 10 min", snoozePi);
        nm.notify(id == null ? 1 : id.hashCode(), b.build());
    }

    private void rescheduleThisMedicine(Context context, String id) {
        if (id == null) return;
        String json = context.getSharedPreferences(ReminderScheduler.PREFS, Context.MODE_PRIVATE).getString(ReminderScheduler.KEY_JSON, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject med = arr.optJSONObject(i);
                if (med != null && id.equals(med.optString("id"))) {
                    android.app.AlarmManager am = (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                    if (am != null) ReminderScheduler.scheduleNext(context, am, med);
                    break;
                }
            }
        } catch (Exception ignored) { }
    }

    private void scheduleSnooze(Context context, Intent source) {
        Intent next = new Intent(context, MedicineAlarmReceiver.class).setAction("com.medicare.companion.MEDICINE_ALARM");
        for (String key : new String[]{"med_id", "med_name", "dosage", "food"}) next.putExtra(key, source.getStringExtra(key));
        PendingIntent pi = PendingIntent.getBroadcast(context, 9000 + (source.getStringExtra("med_id") == null ? 0 : source.getStringExtra("med_id").hashCode()), next, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.AlarmManager am = (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long snoozeAt = System.currentTimeMillis() + 10 * 60 * 1000L;
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, snoozeAt, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, snoozeAt, pi);
            } else {
                am.set(android.app.AlarmManager.RTC_WAKEUP, snoozeAt, pi);
            }
        } catch (SecurityException denied) {
            try { am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, snoozeAt, pi); }
            catch (SecurityException ignored) { }
        }
    }
}
