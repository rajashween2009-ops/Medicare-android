# No custom ProGuard rules are required for this initial WebView wrapper.
