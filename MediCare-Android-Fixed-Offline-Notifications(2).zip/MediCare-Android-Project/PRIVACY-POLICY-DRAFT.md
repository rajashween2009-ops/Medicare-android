# MediCare Privacy Policy — Draft for review

**Do not publish this draft unchanged.** Replace the bracketed publisher contact details and verify the app's actual behavior before release.

MediCare is a medication reminder tool. The app may store medicine names, dosage instructions, reminder schedules, dose logs, optional medical ID information, and emergency contact details on the device using local browser storage.

The current app project does not include a MediCare account system or a MediCare-operated cloud database. The bundled page loads styling and font resources from third-party content delivery services when an internet connection is available; those services may receive ordinary connection data such as IP address. The publisher must verify all network requests and update this notice if any analytics, crash reporting, backup, or other services are added.

Users should protect access to their device and exported backup files. Removing the app or clearing app data may remove locally stored information. The app should not be used as a substitute for professional medical advice or an independently verified medication schedule.

Privacy contact: [publisher email]
Last updated: [date]
